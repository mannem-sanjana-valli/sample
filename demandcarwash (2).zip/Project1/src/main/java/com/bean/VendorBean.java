package com.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class VendorBean {

	@NotBlank(message = "First Name is mandatory")
	private String firstName;
	private String lastName="null";
	@NotBlank(message="Age is mandatory")
	private String age;
	@NotBlank(message="Gender is mandatory")
	private String gender;
	@NotBlank(message = "Contact Number is mandatory")
	@Pattern(regexp="^[7-9]{1}[0-9]{9}",message="Contact number should be ten digits")
	private String contactNumber;
	@NotBlank(message = "Password is mandatory")
	private String password;
	@NotBlank(message = "VendorId is mandatory")
	private String vendorId;
	private String errorcheck;
	private String landlineNumber;
	private String address;
	private String emailId;
	private String washingCenterName;
	private String washType1;
	private String washType2;
	private String washType3;
	private String timeslotOne;
	private String timeslotTwo;
	private String timeslotThree;
	private String washingCenterAddress;
	private String landmark;
	private String washingCenterContact;
	private String washingCenterTime;
	private String googleLocation;
	public String getLandlineNumber() {
		return landlineNumber;
	}

	public void setLandlineNumber(String landlineNumber) {
		this.landlineNumber = landlineNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getWashingCenterName() {
		return washingCenterName;
	}

	public void setWashingCenterName(String washingCenterName) {
		this.washingCenterName = washingCenterName;
	}
	public String getWashingCenterAddress() {
		return washingCenterAddress;
	}

	public void setWashingCenterAddress(String washingCenterAddress) {
		this.washingCenterAddress = washingCenterAddress;
	}

	public String getWashingCenterContact() {
		return washingCenterContact;
	}

	public void setWashingCenterContact(String washingCenterContact) {
		this.washingCenterContact = washingCenterContact;
	}

	public String getWashingCenterTime() {
		return washingCenterTime;
	}

	public void setWashingCenterTime(String washingCenterTime) {
		this.washingCenterTime = washingCenterTime;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getErrorcheck() {
		return errorcheck;
	}

	public void setErrorcheck(String errorcheck) {
		this.errorcheck = errorcheck;
	}

	public String getWashType1() {
		return washType1;
	}

	public void setWashType1(String washType1) {
		this.washType1 = washType1;
	}

	public String getWashType2() {
		return washType2;
	}

	public void setWashType2(String washType2) {
		this.washType2 = washType2;
	}

	public String getWashType3() {
		return washType3;
	}

	public void setWashType3(String washType3) {
		this.washType3 = washType3;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getGoogleLocation() {
		return googleLocation;
	}

	public void setGooglelocation(String googleLocation) {
		this.googleLocation = googleLocation;
	}

	public String getTimeslotOne() {
		return timeslotOne;
	}

	public void setTimeslotOne(String timeslotOne) {
		this.timeslotOne = timeslotOne;
	}

	public String getTimeslotTwo() {
		return timeslotTwo;
	}

	public void setTimeslotTwo(String timeslotTwo) {
		this.timeslotTwo = timeslotTwo;
	}

	public String getTimeslotThree() {
		return timeslotThree;
	}

	public void setTimeslotThree(String timeslotThree) {
		this.timeslotThree = timeslotThree;
	}

}
