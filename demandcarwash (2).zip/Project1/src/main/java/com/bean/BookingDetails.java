package com.bean;

public class BookingDetails {
	private String userId;
	private String vendorId;
	private String timeSlot;
	private String carwashType;
	private String carwashBill;
	private String bookingStatus="pending";
	private String serviceDate;
	private String userAddress;
	private String timeslotCheck;
	private String billstatus="notpaid";
	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}

	public String getCarwashType() {
		return carwashType;
	}

	public void setCarwashType(String carwashType) {
		this.carwashType = carwashType;
	}

	public String getCarwashBill() {
		return carwashBill;
	}

	public void setCarwashBill(String carwashBill) {
		this.carwashBill = carwashBill;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getTimeslotCheck() {
		return timeslotCheck;
	}

	public void setTimeslotCheck(String timeslotCheck) {
		this.timeslotCheck = timeslotCheck;
	}

	public String getBillstatus() {
		return billstatus;
	}

	public void setBillstatus(String billstatus) {
		this.billstatus = billstatus;
	}

}
