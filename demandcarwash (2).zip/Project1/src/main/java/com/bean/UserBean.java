package com.bean;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class UserBean{
	
	@NotBlank(message = "First Name is mandatory")
	private String firstName;
	private String Last_name="null";
	@NotBlank(message = "Contact Number is mandatory")
	@Pattern(regexp="^[7-9]{1}[0-9]{9}",message="Contact number should be ten digits") 
	private String Contact_Number;
	@NotBlank(message = "Email is mandatory")
	@javax.validation.constraints.Email
	private String email;
	@NotBlank(message = "Password is mandatory")
	private String password;
	private String billstatus;
	private String carwashType;
	private String carwashBill;
	private String timeSlot;
	private String errorcheck;

	public String getLast_name() {
		return Last_name;
	}

	public void setLast_name(String last_name) {
		Last_name = last_name;
	}

	public String getContact_Number() {
		return Contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		Contact_Number = contact_Number;
	}
	public String getErrorcheck() {
		return errorcheck;
	}

	public void setErrorcheck(String errorcheck) {
		this.errorcheck = errorcheck;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getBillstatus() {
		return billstatus;
	}

	public void setBillstatus(String billstatus) {
		this.billstatus = billstatus;
	}

	public String getCarwashType() {
		return carwashType;
	}

	public void setCarwashType(String carwashType) {
		this.carwashType = carwashType;
	}

	public String getCarwashBill() {
		return carwashBill;
	}

	public void setCarwashBill(String carwashBill) {
		this.carwashBill = carwashBill;
	}

	public String getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
}
