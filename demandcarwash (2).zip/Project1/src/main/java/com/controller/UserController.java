package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.AdminBean;
import com.bean.BookingDetails;
import com.bean.SearchService;
import com.bean.UserBean;
import com.bean.VendorBean;
import com.service.ServiceDao;
import com.validate.Validate;

@Controller
public class UserController {

	@Autowired
	private ServiceDao service;

	@Autowired
	private Validate validate;

	@ModelAttribute("index")
	public UserBean userBean() {
		return new UserBean();
	}

	@ModelAttribute("aindex")
	public AdminBean adminBean() {
		return new AdminBean();
	}

	@ModelAttribute("vindex")
	public VendorBean vendorBean() {
		return new VendorBean();
	}
	@ModelAttribute("search")
	public SearchService searchservice() {
		return new SearchService();
	}
	@ModelAttribute("bookdetails")
	public BookingDetails bookingdetails() {
		return new BookingDetails();
	}
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String showIndexpage(@ModelAttribute("index") UserBean index) {

		return "Homepage";

	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String User(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Index";

	}

	@RequestMapping(value = "/submitlogin", method = RequestMethod.POST)
	public String LoginValidation(@Valid @ModelAttribute("index") UserBean index, BindingResult result,Model m) {
		validate.userpassworderror(index, result);
		if (service.userloginvalidate(index)) {
			if(service.useralreadybooked(index)) {
				service.fetchuserbookingdetails(index);
				return "BillPayment";
			}
			else {
				service.fetchuserdetails(index);
				m.addAttribute("userindex", index);
				List<SearchService> list = null;
				m.addAttribute("searchList", list);
				return "Login";
			}
			
		}
		else if (result.hasErrors()) {
			return "Index";
		}
		return "Index";

	}

	@RequestMapping(value = "/submitsignup", method = RequestMethod.POST)
	public String RegistrationPageDisplay(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Registration";
	}

	@RequestMapping(value = "/submitregistration", method = RequestMethod.POST)
	public String RegistrationValidations(@Valid @ModelAttribute("index") UserBean index, BindingResult result) {

		validate.validate(index, result);
		if (result.hasErrors()) {
			return "Registration";
		} else if (service.userinsertvalues(index) > 0) {
			return "Index";
		}
		return "Registration";
	}

	@RequestMapping(value = "/admin", method = RequestMethod.POST)
	public String Admin(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		return "AdminIndex";

	}

	@RequestMapping(value = "/submitadminlogin", method = RequestMethod.POST)
	public String AdminLoginVlidation(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		validate.adminpassworderror(aindex, result);
		if (result.hasErrors()) {
			return "AdminIndex";
		}
		if (service.adminloginvalidate(aindex)) {
			return "AdminHomePage";
		}
		return "AdminIndex";

	}

	@RequestMapping(value = "/submitadminsignup", method = RequestMethod.POST)
	public String AdminRegistrationPageDisplay(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		return "AdminRegistration";
	}

	@RequestMapping(value = "/submitadminregistration", method = RequestMethod.POST)
	public String AdminRegistrationValidations(@Valid @ModelAttribute("aindex") AdminBean aindex,
			BindingResult result) {

		validate.validate1(aindex, result);
		if (result.hasErrors()) {
			return "AdminRegistration";
		} else if (service.admininsertvalues(aindex) > 0) {
			return "AdminIndex";
		}
		return "AdminRegistration";
	}

	@RequestMapping(value = "/vendor", method = RequestMethod.POST)
	public String Vendor(@ModelAttribute("vindex") VendorBean vindex, BindingResult result) {
		return "VendorIndex";

	}

	@RequestMapping(value = "/submitvendorlogin", method = RequestMethod.POST)
	public String VendorLoginValidation(@ModelAttribute("vindex") VendorBean vindex, BindingResult result, Model m) {
		validate.vendorpassworderror(vindex, result);
		if(result.hasErrors())
		{
			return "VendorIndex";
		}
		if (service.vendorloginvalidate(vindex)) 
		{
			service.washingservicecheck(vindex);
			service.fetchvendordetails(vindex);
			m.addAttribute("vendorindex", vindex);
			return "VendorHomePage";
		}
		return "VendorIndex";

	}

	@RequestMapping(value = "/submitvendorsignup", method = RequestMethod.POST)
	public String VendorRegistrationPageDisplay(@ModelAttribute("vindex") VendorBean vindex, BindingResult result) {
		return "VendorRegistration";
	}

	@RequestMapping(value = "/submitvendorregistration", method = RequestMethod.POST)
	public String VendorRegistrationValidations(@Valid @ModelAttribute("vindex") VendorBean vindex,BindingResult result) {
		validate.vendor(vindex, result);
		if (result.hasErrors()) {
			return "VendorRegistration";
		} else if (service.vendorinsertvalues(vindex) > 0) {
			return "VendorIndex";
		}
		return "VendorRegistration";
	}
	@RequestMapping(value = "/ServiceCenterDetails", method = RequestMethod.POST)
	public String vendorWashingServiceDetailsUpdate(@ModelAttribute("vindex") VendorBean vindex,BindingResult result,Model m) {
		if(service.vendorservicecheck(vindex))
		{
			if(service.updateServiceDetails(vindex)>0)
			{
				service.fetchvendordetails(vindex);
				m.addAttribute("vindex", vindex);
				return "VendorHomePage";
			}
		}
		else {
		if(service.insertServiceDetails(vindex)>0)
		{
			service.fetchvendordetails(vindex);
			m.addAttribute("vindex", vindex);
			return "VendorHomePage";
		}
		}
		return "Login";
	}
	@RequestMapping(value = "/Updatepersonaldetails", method = RequestMethod.POST)
	public String vendorDetailsUpdate(@ModelAttribute("vindex") VendorBean vindex,BindingResult result,Model m) {
		if(service.updateServiceDetails(vindex)>0)
		{
			service.fetchvendordetails(vindex);
			m.addAttribute("vindex", vindex);
			return "VendorHomePage";
		}
		return "Login";
	}
	@RequestMapping(value = "/searchdisplay", method = RequestMethod.POST)
	public String SearchDisplay(@ModelAttribute("userindex") UserBean userindex,@ModelAttribute("search") SearchService searchService,BindingResult result,Model m) {
		List<VendorBean> list=service.searchResults(searchService);
		m.addAttribute("searchList", list);
		return "Login";
	}
	@RequestMapping(value = "/bookservice", method = RequestMethod.POST)
	public String GetDetails(@ModelAttribute("index") UserBean index,@ModelAttribute("vindex") VendorBean vindex,@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,Model m,@RequestParam(value="vendor",defaultValue = "0") String selectedcenter) {
		vindex.setVendorId(selectedcenter);
		bookdetails.setVendorId(selectedcenter);
		service.washingservicecheck(vindex);
		m.addAttribute("bookservice", vindex);
		m.addAttribute("bookdetails", bookdetails);
		return "BookWashService";
		
	}
	@RequestMapping(value = "/selectservices", method = RequestMethod.POST)
	public String BookcarServices(@ModelAttribute("index") UserBean index,@ModelAttribute("vindex") VendorBean vindex,@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,Model m,@RequestParam(value="slots",defaultValue = "0") String timeslot,@RequestParam(value="types",defaultValue = "0") String washtype) {
		bookdetails.setTimeSlot(timeslot);
		validate.slotcheck(bookdetails, result);
		if(result.hasErrors())
		{
			vindex.setVendorId(bookdetails.getVendorId());
			bookdetails.setVendorId(bookdetails.getVendorId());
			service.washingservicecheck(vindex);
			m.addAttribute("bookservice", vindex);
			m.addAttribute("bookdetails", bookdetails);
			return "BookWashService";
		}
		if(service.userloginvalidate(index))
		{
			service.fetchuserdetails(index);
			bookdetails.setUserId(index.getEmail());
			String bill=washtype.replaceAll("[^0-9]", "");
			String washtypes=washtype.replaceAll("[^a-zA-Z]", "");
			bookdetails.setTimeSlot(timeslot);
			bookdetails.setCarwashType(washtypes);
			bookdetails.setCarwashBill(bill);
			if(service.insertbookingdetails(bookdetails)>0) {
				return "xyz";
			}
		}
		return "BookWashService";
	}
	@RequestMapping(value = "/gotogateway", method = RequestMethod.POST)
	public String gotoGateway(@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,@RequestParam(value="userid",defaultValue = "0") String userid,@RequestParam(value="billamount",defaultValue = "0") String billamount,Model m) {
		bookdetails.setUserId(userid);
		bookdetails.setCarwashBill(billamount);
		m.addAttribute("bookdetails", bookdetails);
		return "PaymentGateWay";
	}
	@RequestMapping(value = "/paybill", method = RequestMethod.POST)
	public String Payment(@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,@RequestParam(value="userid",defaultValue = "0") String userid,@RequestParam(value="billamount",defaultValue = "0") String billamount) {
		return "xyz";
	}
	@RequestMapping(value = "/forgetpassword", method = RequestMethod.POST)
	public String Forgotpassword(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Forgotpassword";

	}
}