package com.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.bean.AdminBean;
import com.bean.BookingDetails;
import com.bean.UserBean;
import com.bean.VendorBean;
import com.service.ServiceDao;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date; 

@Component
public class Validate implements Validator {

	@Autowired
	private ServiceDao service;

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		UserBean userbean = (UserBean) target;
		if (service.userduplicatecheck(userbean)) {
			errors.rejectValue("Email", "error.Email", "Email already registered");
		}
	}

	public void validate1(Object target, Errors errors) {
		// TODO Auto-generated method stub
		AdminBean adminbean = (AdminBean) target;
		if (service.adminduplicatecheck(adminbean)) {
			errors.rejectValue("Email", "error.Email", "Email already registered");
		}
	}

	public void vendor(Object target, Errors errors) {
		// TODO Auto-generated method stub
		VendorBean vendorbean = (VendorBean) target;
		if (service.vendorduplicatecheck(vendorbean)) {
			errors.rejectValue("vendorId", "error.vendorId", "Vendor_Id already exist");
		}
	}

	public void userpassworderror(Object target, Errors errors) {
		// TODO Auto-generated method stub
		UserBean userbean = (UserBean) target;
		if (!(service.userloginvalidate(userbean))) {
			errors.rejectValue("errorcheck", "error.errorcheck", "Username or Password is incorrect");
		}
	}

	public void adminpassworderror(Object target, Errors errors) {
		// TODO Auto-generated method stub
		AdminBean adminbean = (AdminBean) target;
		if (!(service.adminloginvalidate(adminbean))) {
			errors.rejectValue("errorcheck", "error.errorcheck", "Username or Password is incorrect");
		}
	}

	public void vendorpassworderror(Object target, Errors errors) {
		// TODO Auto-generated method stub
		VendorBean vendorbean = (VendorBean) target;
		if (!(service.vendorloginvalidate(vendorbean))) {
			errors.rejectValue("errorcheck", "error.errorcheck", "Username or Password is incorrect");
		}

	}

	public void slotcheck(Object target, Errors errors) {
		// TODO Auto-generated method stub
		BookingDetails bookingdetails=(BookingDetails)target;
		if(service.slotbookingcheck(bookingdetails)) 
		{
			errors.rejectValue("timeslotCheck", "error.timeslotCheck", "TimeSlot is booked change the time slot");
		}
	}
}
